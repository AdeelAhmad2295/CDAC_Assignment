package Assignment27Sept;
import java.util.*;

public class Assignment27Sept_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
    	System.out.println("Enter the value of n:");
    	int n =s.nextInt();
    	for(int i=1;i<=n;i++) {
    		for(int j=1;j<=n;j++) {
        		System.out.print(j+"\t");
    		}
    		System.out.println();
    	}
	}

}
