package Assignment27Sept;

import java.util.Scanner;

public class Assingment27Sept_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	Scanner s=new Scanner(System.in);
    	System.out.println("Enter the value of n:");
    	int n =s.nextInt();

        // Loop for each row
        for (int i = 0; i < n; i++) {
            // Print the pattern in each row using tab spaces
            System.out.println("*\t* *\t*\t*");
        }
	}

}
