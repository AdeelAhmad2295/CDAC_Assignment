package Assignment27Sept;
import java.util.*;
public class Assignment27Sept_18 {

	    public static void main(String[] args) {
	        // Number of rows
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter the value of n:");
	    	int n =s.nextInt();
	        for (int i = 1; i <= n; i++) {
	            for (int j = 1; j <= n; j++) {
	                if (i == 1 || i == n || j == 1 || j == n) {
	                    System.out.print("*"); 
	                } else {
	                    System.out.print("#");
	                }
	            }
	            System.out.println();
	        }
	}

}