package Assignment27Sept;
import java.util.*;
public class Assignment27Sept_4 {

	    public static void main(String[] args) {
	        // Number of rows
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter the value of n:");
	    	int n =s.nextInt();
	    	 for (int i=0;i<n;i++) {
	             // Loop through columns
	             for (int j=0;j<n;j++) {
	                 System.out.print((char)('A' +i+j)+" ");
	             }
	             System.out.println();
	         }

	    }
	}

