package Assignment27Sept;
import java.util.*;
public class Assignment27Sept_8 {

	    public static void main(String[] args) {
	        // Number of rows
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter the value of n:");
	    	int n =s.nextInt();
	        for (int i = 1; i <= n; i++) {
	            for (int j = 1; j <= i; j++) {
	                System.out.print(j + " ");
	            }
	            System.out.println();
	        }
	    }
	}

