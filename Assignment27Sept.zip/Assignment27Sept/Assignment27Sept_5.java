package Assignment27Sept;
import java.util.*;
public class Assignment27Sept_5 {

	    public static void main(String[] args) {
	        // Number of rows
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter the value of n:");
	    	int n =s.nextInt();
	        for (int i=0;i<n;i++) {
	            for (int j=0;j<n;j++) {
	                if((i+j)%2==0) {
	                    System.out.print("0 ");
	                } 
	                else{
	                    System.out.print("1 ");
	                }
	            }
	            System.out.println();
	        }
	    }
	}

