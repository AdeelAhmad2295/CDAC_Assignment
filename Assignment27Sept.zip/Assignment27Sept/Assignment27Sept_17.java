package Assignment27Sept;
import java.util.*;
public class Assignment27Sept_17 {

	    public static void main(String[] args) {
	        // Number of rows
	    	Scanner s=new Scanner(System.in);
	    	System.out.println("Enter the value of n:");
	    	int n =s.nextInt();
	        for (int i = 1; i <= n; i++) {
	            for (int j = n; j > i; j--) {
	                System.out.print(" "); 
	            }
	            System.out.print("*");
	            if (i > 1) {
	                for (int j = 1; j < (2 * i - 1); j++) {
	                    System.out.print(" "); 
	                }
	                System.out.print("*");
	            }
	            System.out.println();
	        }
	        
	        for (int i = 1; i <= (2 * n - 1); i++) {
	            System.out.print("*"); 
	        }
	        System.out.println();
	    }
	}

